# M-E-Text-Based-Adventure-Game
main.py is current version of the game

-------------------------------------------------------------

Windows

to run first install python 3.x from https://www.python.org/downloads

after run main.py

-------------------------------------------------------------

ubuntu 20.04

open terminal and install python3 with 

sudo apt install -y python3-pip

then sudo apt install -y build-essential libssl-dev libffi-dev python3-dev

then download file and extract, move main.py to home folder

use "cd /home/usr/

then "python3 main.py

if you have trouble finding the directory install tree via terminal 

-------------------------------------------------------------------------------------

android

download pydroid 3 from the playstore

download mai.py

load in pydroid 3 and hit launch

https://moddayhippie.itch.io/m-e-text-based-adventure-game
